
package Control;

import Server.Servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;

/**
 *
 * @author mayron
 */
public class GerenciaConexoes implements Runnable {

    private Socket socket;
    private String dados;
    private Servidor servidor;
    private boolean run;

    public GerenciaConexoes(Socket socket, String dados, Servidor servidor) {
        this.socket = socket;
        this.dados = dados;
        this.servidor = servidor;
        this.run = false;
    }

    @Override
    public void run() {
        String dados;
        run = true;
        while (run) {
            dados = GerenciaMensagens.recebeDados(socket);
            JSONObject jobj = GerenciaMensagens.parserDados(dados);
            if (jobj.get("instrucao") == null) {
                servidor.addUser(dados);
                System.out.println("Novo usuário cadastrado!");
            } else {
                if (jobj.get("instrucao").equals("listar")) {
                    String retorno = servidor.getUsers();
                    GerenciaMensagens.enviaDados(retorno, socket);
                } else {
                    if (jobj.get("instrucao").equals("off")) {
                        servidor.setUsuarios(servidor.excluirUser(dados));
                        run = false;
                        try {
                            socket.close();
                        } catch (IOException ex) {
                            Logger.getLogger(GerenciaConexoes.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        if (jobj.get("instrucao").equals("excluir")) {
                            servidor.setUsuarios(servidor.excluirUser(dados));
                        }
                    }
                }
            }
        }
    }

    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }
}
