package Control;

import View.Chat;
import View.MenuUsuarios;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;

/**
 *
 * @author mayron
 */
public class GerenciaChat implements Runnable {

    private String dadosUsuario;
    private Socket socket;
    private boolean chatRunnig;
    private boolean run;
    private Chat chat;
    private MenuUsuarios menu;

    public GerenciaChat(Socket socket, MenuUsuarios menu) {
        this.dadosUsuario = null;
        this.socket = socket;
        this.chatRunnig = false;
        this.run = false;
        this.chat = null;
        this.menu = menu;
    }

    @Override
    public void run() {
        String dados;
        run = true;
        while (run) {
            dados = GerenciaMensagens.recebeDados(socket);
            JSONObject jobj = GerenciaMensagens.parserDados(dados);
            String clientInfos = jobj.get("nome") + ";" + jobj.get("enderecoip") + ";" + jobj.get("porta");
            if (jobj.get("instrucao") == null) {
                if (chatRunnig == false) {
                    chatRunnig = true;
                    chat = new Chat(menu, socket, clientInfos);
                }else{
                    chat.recebeMensagem(dados);
                }
            } else {
                if (jobj.get("instrucao").equals("off")) {
                    if (chatRunnig) {
                        chatRunnig = false;
                        try {
                            socket.close();
                        } catch (IOException ex) {
                            System.err.println("Erro ao encerrar chat");
                        }
                        chat.dispose();
                    }
                    run = false;
                }
            }
        }
    }

    public boolean isChatRunnig() {
        return chatRunnig;
    }

    public void setChatRunnig(boolean chatRunnig) {
        this.chatRunnig = chatRunnig;
    }

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

}
