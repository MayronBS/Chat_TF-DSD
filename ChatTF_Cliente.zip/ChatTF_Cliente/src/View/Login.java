package View;

import Cliente.Cliente;
import Control.GerenciaMensagens;
import java.io.IOException;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author mayron
 */
public class Login extends javax.swing.JFrame {

    private Cliente c;

    public Login() {
        initComponents();
    }
    
    private void entrar(){
        try {
            c = new Cliente();
            c.setNome(tfNome.getText());
            c.setServerIp(tfIpserver.getText());
            c.setPorta(tfPorta.getText());

            c.ConectServer(c.getServerIp());
            c.setIp(c.getUserSocket().getLocalAddress().getHostAddress());
            GerenciaMensagens.enviaDados(GerenciaMensagens.msgListar(), c.getUserSocket());
            String retorno = GerenciaMensagens.recebeDados(c.getUserSocket());
            System.out.println(retorno + "  retorno");
            c.listarUsers(retorno);

            boolean b = verificalogin(c.getUsuariosConectados());
            if (b == false) {
                JOptionPane.showMessageDialog(null, "Esta porta de usuário já está em uso!");
            } else {
                System.out.println("logar user");
                GerenciaMensagens.login(c.getUserSocket(), c);
                MenuUsuarios menuUsuarios = new MenuUsuarios(c);
                menuUsuarios.setVisible(true);
                menuUsuarios.getJlNome().setText(c.getNome());
                this.dispose();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Endereço Ip errado ou o Servidor está inopernate!");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfNome = new javax.swing.JTextField();
        tfPorta = new javax.swing.JTextField();
        tfIpserver = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btEntrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tfNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNomeActionPerformed(evt);
            }
        });

        tfPorta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPortaActionPerformed(evt);
            }
        });

        tfIpserver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIpserverActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome de Usuário:");

        jLabel2.setText("Porta do Usuário:");

        jLabel3.setText("IP do servidor:");

        btEntrar.setText("Entrar");
        btEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEntrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(tfIpserver, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfPorta, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(btEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(tfPorta, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfIpserver, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(btEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNomeActionPerformed

    private void tfPortaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPortaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfPortaActionPerformed

    private void tfIpserverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIpserverActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfIpserverActionPerformed

    private void btEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEntrarActionPerformed
        entrar();
        
//        try {
//            c = new Cliente();
//            c.setNome(tfNome.getText());
//            c.setServerIp(tfIpserver.getText());
//            c.setPorta(tfPorta.getText());
//
//            c.ConectServer(c.getServerIp());
//            c.setIp(c.getUserSocket().getLocalAddress().getHostAddress());
//            GerenciaMensagens.enviaDados(GerenciaMensagens.msgListar(), c.getUserSocket());
//            String retorno = GerenciaMensagens.recebeDados(c.getUserSocket());
//            System.out.println(retorno + "  retorno");
//            c.listarUsers(retorno);
//
//            boolean b = verificalogin(c.getUsuariosConectados());
//            if (b == false) {
//                JOptionPane.showMessageDialog(null, "Esta porta de usuário já está em uso!");
//            } else {
//                System.out.println("logar user");
//                GerenciaMensagens.login(c.getUserSocket(), c);
//                MenuUsuarios menuUsuarios = new MenuUsuarios(c);
//                menuUsuarios.setVisible(true);
//                menuUsuarios.getJlNome().setText(c.getNome());
//                this.dispose();
//            }
//        } catch (IOException ex) {
//            JOptionPane.showMessageDialog(null, "Endereço Ip errado ou o Servidor está inopernate!");
//        }

    }//GEN-LAST:event_btEntrarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEntrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField tfIpserver;
    private javax.swing.JTextField tfNome;
    private javax.swing.JTextField tfPorta;
    // End of variables declaration//GEN-END:variables

    private boolean verificalogin(JSONArray listUsers) {
        JSONObject jobj = new JSONObject();
        boolean b = true;
        for (Object user : listUsers) {
            jobj = (JSONObject) user;
            if (jobj.get("porta").equals(c.getPorta())) {
                b = false;
            }
        }
        return b;
    }
}
