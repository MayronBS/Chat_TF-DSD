/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Cliente.Cliente;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author mayro
 */
public class GerenciaMensagens {
    private static String dados = "";
    
    public static void enviaDados(String dados,Socket socket){
        try {
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            
            out.writeUTF(dados);
            out.flush();
        } catch (Exception e) {
        }
    }
    
    public static String recebeDados(Socket socket){
        
        try {
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            dados = in.readUTF();
        } catch (Exception e) {
        }
        return dados;
    }
    
    public static String dadosUser(Cliente c){
        JSONObject dados = new JSONObject();
        dados.put("nome", c.getNome());
        dados.put("endereco", c.getIp());
        dados.put("porta", c.getPorta());
        
        JSONArray l = new JSONArray();
            l.add(dados);

            String mensagem = JSONArray.toJSONString(l);
        
        return mensagem;
    }
    
    public static String login(Socket socket, Cliente c){
        enviaDados(dadosUser(c), socket);
        String retorno = recebeDados(socket);
        return retorno;
    }
}
