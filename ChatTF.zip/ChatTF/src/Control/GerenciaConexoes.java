/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Server.Servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mayron
 */
public class GerenciaConexoes implements Runnable {

    private Socket socket;
    private String dados;
    private Servidor servidor;
    private boolean run;

    public GerenciaConexoes(Socket socket, String dados, Servidor servidor) {
        this.socket = socket;
        this.dados = dados;
        this.servidor = servidor;
        this.run = false;
    }

    public boolean isRun() {
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }

    

    @Override
    public void run() {
        run = true;
        String dados;
        while (run) {            
            dados = GerenciaMensagens.recebeDados(socket);
        }
    }

}
