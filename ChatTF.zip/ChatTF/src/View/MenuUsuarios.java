package View;

import Cliente.Cliente;
import Control.GerenciaChat;
import Control.GerenciaMensagens;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import org.json.simple.JSONObject;

/**
 *
 * @author mayron
 */
public class MenuUsuarios extends javax.swing.JFrame {

    private Cliente c;
    private ArrayList<String> usuarios;
    private ServerSocket svCliente;
    private boolean run;

    public MenuUsuarios(Cliente c) {
        run = false;
        svCliente = null;
        this.jList = new JList<>();
        this.usuarios = new ArrayList<String>();
        this.c = c;
        initComponents();
        clientStartSrv(this, Integer.parseInt(c.getPorta()));
    }

    public Cliente getC() {
        return c;
    }

    
    public JLabel getJlNome() {
        return jlNome;
    }

    public void setJlNome(JLabel jlNome) {
        this.jlNome = jlNome;
    }
    
    private void clientStartSrv(MenuUsuarios menu, int porta){
        new Thread(){
            @Override
            public void run(){
                run = true;
                try {
                    svCliente = new ServerSocket(porta);
                    while (run) {                        
                        Socket socket = svCliente.accept();
                        GerenciaChat gc = new GerenciaChat(socket, menu);
                        new Thread(gc).start();
                    }
                } catch (Exception e) {
                    System.err.println("erro Start server client"+ e);
                }
            }
        };
    }

    private void atualizarLista() {
        GerenciaMensagens.enviaDados(GerenciaMensagens.msgListar(), c.getUserSocket());
        String retorno = GerenciaMensagens.recebeDados(c.getUserSocket());
        System.out.println(retorno + "  retorno de usuários!!");
        c.listarUsers(retorno);
        usuarios.clear();
        jList.removeAll();
        
        DefaultListModel model = new DefaultListModel();
        JSONObject jobj = new JSONObject();
        for (Object user : c.getUsuariosConectados()) {
            jobj = (JSONObject) user;
            if (jobj.get("porta").equals(c.getPorta())) {
            } else {
                String c = jobj.get("nome")+";"+jobj.get("enderecoip")+";"+jobj.get("porta");
                model.addElement(c);
            }
        }
        jList.setModel(model);

    }
    
    private void iniciarChat(){
        int index = jList.getSelectedIndex();
        if (index != -1) {
            String dados = jList.getSelectedValue().toString();
            String[] inf = dados.split(";");
            System.out.println(inf[1]);
            try {
                Socket socket = new Socket(inf[1], Integer.parseInt(inf[2]));
                GerenciaMensagens.enviaDados(GerenciaMensagens.dadosUser(c), socket);
                GerenciaChat gc = new GerenciaChat(socket, this);
                gc.setChat(new Chat(this, socket, dados));
                gc.setChatRunnig(true);
            } catch (Exception e) {
                System.err.println("Erro ao iniciar chat: "+ e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        btiniciarChat = new javax.swing.JButton();
        btAtualizar = new javax.swing.JButton();
        jlNome = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chat");
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jList.setName(""); // NOI18N
        jList.setSelectionBackground(new java.awt.Color(204, 204, 204));
        jScrollPane1.setViewportView(jList);

        jLabel1.setText("Usuário:");

        btiniciarChat.setText("Iniciar chat");
        btiniciarChat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btiniciarChatActionPerformed(evt);
            }
        });

        btAtualizar.setText("atualizar");
        btAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAtualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jlNome, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btiniciarChat, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btAtualizar)
                        .addGap(19, 19, 19))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlNome, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btiniciarChat, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btAtualizar))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btiniciarChatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btiniciarChatActionPerformed
        iniciarChat();
    }//GEN-LAST:event_btiniciarChatActionPerformed

    private void btAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAtualizarActionPerformed
        atualizarLista();
    }//GEN-LAST:event_btAtualizarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAtualizar;
    private javax.swing.JButton btiniciarChat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jlNome;
    // End of variables declaration//GEN-END:variables
}
