
package Server;

import Control.GerenciaConexoes;
import Control.GerenciaMensagens;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author mayron
 */
public class Servidor {

    private ServerSocket serverSocket;
    public static final int PORTASERVIDOR = 5555;
    private static JSONArray usuarios;

    public void iniciar() {
        usuarios = new JSONArray();
        String dados;
        try {
            serverSocket = new ServerSocket(PORTASERVIDOR);
            System.out.println("Servidor iniciado!");
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }

        while (true) {
            try {
                Socket socket = serverSocket.accept();
                dados = GerenciaMensagens.recebeDados(socket);
                System.out.println(dados + "dados");
                JSONObject jobj = GerenciaMensagens.parserDados(dados);
                if (jobj.get("instrucao") == null) {
                    addUser(dados);
                    System.out.println("Novo usuário cadastrado!");
                    System.out.println(usuarios.toJSONString());
                } else {
                    if (jobj.get("instrucao").equals("listar")) {
                        String retorno = getUsers();
                        System.out.println("Usuários conectados:  " + retorno);
                        GerenciaMensagens.enviaDados(retorno, socket);
                    }
                }
                    GerenciaConexoes gcon = new GerenciaConexoes(socket, dados, this);
                    new Thread(gcon).start();
                }catch (IOException ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }

            }
        }

    

    public void addUser(String dados) {
        try {
            JSONParser jParser = new JSONParser();

            Object obj = jParser.parse(dados);

            JSONArray listUsers = (JSONArray) obj;
            JSONObject j = new JSONObject();
            j = (JSONObject) listUsers.get(0);
            usuarios.add(j);
        } catch (ParseException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public JSONArray excluirUser(String dados) {
        JSONObject usuario = GerenciaMensagens.parserDados(dados);
        System.out.println("Usuário excluido" + usuario.toJSONString());
        JSONArray newLista = new JSONArray();
        JSONObject jobj = new JSONObject();
        for (Object user : usuarios) {
            jobj = (JSONObject) user;
            if (jobj.get("porta").equals(usuario.get("porta"))) {
            } else {
                newLista.add(user);
            }
        }
        return newLista;
    }

    public static JSONArray getUsuarios() {
        return usuarios;
    }

    public static void setUsuarios(JSONArray usuarios) {
        Servidor.usuarios = usuarios;
    }

    public String getUsers() {
        String users = JSONArray.toJSONString(usuarios);
        return users;
    }

    public static void main(String[] args) {
        try {
            Servidor servidor = new Servidor();
            servidor.iniciar();

            while (true) {

            }
        } catch (Exception e) {
            System.out.println("Erro na inicialização do Servidor:" + e.getMessage());
        }
    }

}
