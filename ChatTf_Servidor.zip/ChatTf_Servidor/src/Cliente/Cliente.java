package Cliente;

import Control.GerenciaChat;
import Control.GerenciaMensagens;
import View.Login;
import View.MenuUsuarios;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author mayron
 */
public class Cliente {

    private String nome;
    private String ip;
    private String porta;
    private ServerSocket svCliente;
    private String serverIp;
    private Socket userSocket;
    private JSONArray usuariosConectados;
    private boolean run;

    public Cliente(String nome, String ip, String porta, String serverIp) {
        this.nome = nome;
        this.ip = ip;
        this.porta = porta;
        this.serverIp = serverIp;
    }

    public Cliente() {
    }

    public void ConectServer(String ip) throws IOException {
        userSocket = new Socket(ip, Server.Servidor.PORTASERVIDOR);

        System.out.println("Conectado!");

    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Socket getUserSocket() {
        return userSocket;
    }

    public void setUserSocket(Socket userSocket) {
        this.userSocket = userSocket;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPorta() {
        return porta;
    }

    public void setPorta(String porta) {
        this.porta = porta;
    }

    public JSONArray getUsuariosConectados() {
        return usuariosConectados;
    }

    

    public void listarUsers(String mensagem) {
        try {
            JSONParser jParser = new JSONParser();

            Object obj = jParser.parse(mensagem);

            this.usuariosConectados = (JSONArray) obj;

        } catch (ParseException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void main(String[] args) throws IOException {

        Login l = new Login();
        l.setVisible(true);

    }
}
