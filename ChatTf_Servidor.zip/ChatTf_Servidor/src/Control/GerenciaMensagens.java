
package Control;

import Cliente.Cliente;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author mayron
 */
public class GerenciaMensagens {

    private static String dados = "";

    public static void enviaDados(String dados, Socket socket) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

            out.writeUTF(dados);
            out.flush();
        } catch (Exception e) {
        }
    }

    public static String recebeDados(Socket socket) {

        try {
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            dados = in.readUTF();
        } catch (Exception e) {
        }
        return dados;
    }

    public static String dadosUser(Cliente c) {
        JSONObject dados = new JSONObject();
        dados.put("nome", c.getNome());
        dados.put("enderecoip", c.getIp());
        dados.put("porta", c.getPorta());

        JSONArray l = new JSONArray();
        l.add(dados);

        String mensagem = JSONArray.toJSONString(l);

        return mensagem;
    }

    public static void login(Socket socket, Cliente c) {
            enviaDados(dadosUser(c), socket);
            System.out.println("Novo Usuário cadastrado");
        
    }
    
    public static String msgOff(String porta) {
        JSONObject instrucao1 = new JSONObject();
        instrucao1.put("instrucao", "off");
        instrucao1.put("porta", porta);
        JSONArray l = new JSONArray();
        l.add(instrucao1);
        return l.toJSONString();
    }
    
    public static String msgExcluir(String porta) {
        JSONObject instrucao1 = new JSONObject();
        instrucao1.put("instrucao", "excluir");
        instrucao1.put("porta", porta);
        JSONArray l = new JSONArray();
        l.add(instrucao1);
        return l.toJSONString();
    }

    public static String msgListar() {
        JSONObject instrucao1 = new JSONObject();
        instrucao1.put("instrucao", "listar");
        JSONArray l = new JSONArray();
        l.add(instrucao1);
        return l.toJSONString();
    }
    
    public static String msgChat(Cliente c, String msg) {
        DateFormat df = new SimpleDateFormat("hh:mm");
        String hora = df.format(new Date());
        
        JSONObject mensagem = new JSONObject();
        mensagem.put("nome", c.getNome());
        mensagem.put("hora", hora);
        mensagem.put("mensagem", msg);
        
        JSONArray l = new JSONArray();
        l.add(mensagem);
        return l.toJSONString();
    }

    public static JSONObject parserDados(String dados) {
        JSONObject jobj = new JSONObject();
        try {
            JSONParser jParser = new JSONParser();

            Object obj = jParser.parse(dados);

            JSONArray listUsers = (JSONArray) obj;
            jobj = (JSONObject) listUsers.get(0);
        } catch (ParseException ex) {
            Logger.getLogger(GerenciaMensagens.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jobj;

    }
}
